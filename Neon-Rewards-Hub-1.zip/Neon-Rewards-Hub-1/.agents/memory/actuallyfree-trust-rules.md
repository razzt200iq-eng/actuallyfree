---
name: ActuallyFree trust rules
description: Product integrity requirements for the Roblox rewards-discovery platform.
---

ActuallyFree is a rewards-discovery platform for Roblox players. Do not include advertisements or request Roblox passwords. Demo listings may show sample tasks, requirements, durations, statuses, and point amounts only when they are clearly labeled as examples, not live or claimable; preview actions must not submit activity or award points. Never fabricate real earnings, completed missions, live rankings, or Robux payouts. Do not promise automated gameplay or task completion unless the required systems are actually implemented. Use legitimate reward providers and label unavailable data clearly.

Only provider-authenticated callbacks may credit real points, and the reward amount must come from the server-stored mission listing, never the callback payload. Record credits and debits in an idempotent ledger; demo listings never create spendable points. Account-scoped operations must use a trusted authenticated identity, not a client-supplied user ID.

**Why:** The user explicitly set these rules so the platform does not mislead players or collect Roblox credentials.

**How to apply:** Preserve these constraints across future UI, backend, AI, provider integrations, and payout flows. Only show balances, completions, rankings, and payouts backed by verified live data.
