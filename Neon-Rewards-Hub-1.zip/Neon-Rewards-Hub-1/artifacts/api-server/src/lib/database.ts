import { sql } from "drizzle-orm";
import { logger } from "./logger";

type DatabaseClient = typeof import("@workspace/db")["db"];

let databasePromise: Promise<DatabaseClient | null> | undefined;

export function isDatabaseConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL);
}

export async function getDatabase(): Promise<DatabaseClient | null> {
  if (!isDatabaseConfigured()) return null;
  if (databasePromise) return databasePromise;

  databasePromise = import("@workspace/db")
    .then(({ db }) => db)
    .catch((error: unknown) => {
      const errorName = error instanceof Error ? error.name : "UnknownError";
      logger.warn({ errorName }, "Database module could not be initialized");
      databasePromise = undefined;
      return null;
    });

  return databasePromise;
}

export async function getDatabaseState(): Promise<
  "not_configured" | "unavailable" | "connected"
> {
  if (!isDatabaseConfigured()) return "not_configured";

  const database = await getDatabase();
  if (!database) return "unavailable";

  try {
    await database.execute(sql`select 1`);
    return "connected";
  } catch (error) {
    const errorCode =
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      typeof error.code === "string"
        ? error.code
        : "unknown";
    logger.warn({ errorCode }, "Database connection check failed");
    return "unavailable";
  }
}
