import assert from "node:assert/strict";
import test from "node:test";
import { ReceiveRewardProviderCallbackBody } from "@workspace/api-zod";
import {
  calculatePointsBalance,
  processProviderRewardEvent,
  type AttemptRewardContext,
  type ProviderRewardEvent,
  type RewardStore,
  type RewardTransaction,
} from "./reward-engine";
import {
  signProviderPayload,
  verifyProviderSignature,
} from "./provider-signature";

class MemoryRewardStore implements RewardStore {
  events = new Map<
    string,
    { id: string; status: "received" | "applied" | "rejected" }
  >();
  attempts = new Map<string, AttemptRewardContext>();
  ledger: Array<{
    eventId: string;
    userId: string;
    direction: "credit" | "debit";
    amountPoints: number;
    source:
      | "verified_provider_event"
      | "withdrawal_request"
      | "withdrawal_refund";
    sourceId: string;
  }> = [];
  private nextId = 0;

  async transaction<T>(
    operation: (transaction: RewardTransaction) => Promise<T>,
  ): Promise<T> {
    const transaction: RewardTransaction = {
      claimEvent: async (event) => {
        const key = `${event.providerId}:${event.eventId}`;
        if (this.events.has(key)) return null;
        const id = `event-${++this.nextId}`;
        this.events.set(key, { id, status: "received" });
        return id;
      },
      getAttemptForUpdate: async (attemptRef) =>
        this.attempts.get(attemptRef) ?? null,
      setAttemptState: async (attemptId, state) => {
        for (const attempt of this.attempts.values()) {
          if (attempt.attemptId === attemptId) attempt.state = state;
        }
      },
      setEventStatus: async (eventRecordId, status) => {
        for (const event of this.events.values()) {
          if (event.id === eventRecordId) event.status = status;
        }
      },
      insertLedgerEntry: async (entry) => {
        this.ledger.push(entry);
      },
    };

    return operation(transaction);
  }
}

function pendingAttempt(
  overrides: Partial<AttemptRewardContext> = {},
): AttemptRewardContext {
  return {
    attemptId: "attempt-1",
    userId: "user-1",
    state: "pending_verification",
    mission: {
      providerId: "provider-test",
      rewardPoints: 125,
      isDemo: false,
      isActive: true,
    },
    ...overrides,
  };
}

function verifiedEvent(
  overrides: Partial<ProviderRewardEvent> = {},
): ProviderRewardEvent {
  return {
    providerId: "provider-test",
    eventId: "event-test-1",
    attemptRef: "attempt-reference-000000000000000001",
    outcome: "verified",
    ...overrides,
  };
}

test("a duplicate provider callback credits a verified attempt once", async () => {
  const store = new MemoryRewardStore();
  store.attempts.set(
    "attempt-reference-000000000000000001",
    pendingAttempt(),
  );

  const first = await processProviderRewardEvent(verifiedEvent(), store);
  const duplicate = await processProviderRewardEvent(verifiedEvent(), store);

  assert.deepEqual(first, { status: "applied", pointsCredited: 125 });
  assert.deepEqual(duplicate, { status: "duplicate", pointsCredited: 0 });
  assert.equal(store.ledger.length, 1);
  assert.equal(calculatePointsBalance(store.ledger), 125);
});

test("invalid and demo reward events are rejected without credits", async () => {
  const store = new MemoryRewardStore();
  store.attempts.set(
    "attempt-reference-000000000000000001",
    pendingAttempt({
      mission: {
        providerId: "provider-test",
        rewardPoints: 900,
        isDemo: true,
        isActive: true,
      },
    }),
  );

  const demoResult = await processProviderRewardEvent(verifiedEvent(), store);
  const unknownAttemptResult = await processProviderRewardEvent(
    verifiedEvent({
      eventId: "event-unknown-attempt",
      attemptRef: "attempt-reference-unknown-000000000000",
    }),
    store,
  );

  assert.deepEqual(demoResult, { status: "rejected", pointsCredited: 0 });
  assert.deepEqual(unknownAttemptResult, {
    status: "rejected",
    pointsCredited: 0,
  });
  assert.equal(store.ledger.length, 0);
});

test("a provider cannot choose points or verify a non-pending attempt", async () => {
  const store = new MemoryRewardStore();
  store.attempts.set(
    "attempt-reference-000000000000000001",
    pendingAttempt({ state: "started" }),
  );

  const result = await processProviderRewardEvent(verifiedEvent(), store);

  assert.deepEqual(result, { status: "rejected", pointsCredited: 0 });
  assert.equal(store.ledger.length, 0);
});

test("callback validation rejects client-selected rewards and unknown outcomes", () => {
  const validBase = {
    eventId: "provider-event-1",
    attemptRef: "attempt-reference-000000000000000001",
  };
  assert.equal(
    ReceiveRewardProviderCallbackBody.strict().safeParse({
      ...validBase,
      outcome: "verified",
      points: 999_999,
    }).success,
    false,
  );
  assert.equal(
    ReceiveRewardProviderCallbackBody.strict().safeParse({
      ...validBase,
      outcome: "paid",
    }).success,
    false,
  );
});

test("balance calculations add credits and subtract debits", () => {
  const balance = calculatePointsBalance([
    { direction: "credit", amountPoints: 420 },
    { direction: "debit", amountPoints: 75 },
    { direction: "debit", amountPoints: 25 },
  ]);

  assert.equal(balance, 320);
  assert.throws(
    () =>
      calculatePointsBalance([
        {
          direction: "credit",
          amountPoints: 0,
        },
      ]),
    /positive integer/,
  );
});

test("provider signatures reject replayed timestamps and altered bodies", () => {
  const secret = "local-test-secret-long-enough-for-hmac-tests";
  const rawBody = Buffer.from('{"eventId":"evt-1"}');
  const timestamp = "1760000000";
  const signature = signProviderPayload(secret, timestamp, rawBody);

  assert.deepEqual(
    verifyProviderSignature({
      configuredProviderId: "provider-test",
      configuredSecret: secret,
      providerIdHeader: "provider-test",
      timestampHeader: timestamp,
      signatureHeader: signature,
      rawBody,
      nowSeconds: Number(timestamp),
    }),
    { valid: true, timestamp: Number(timestamp) },
  );

  const altered = verifyProviderSignature({
    configuredProviderId: "provider-test",
    configuredSecret: secret,
    providerIdHeader: "provider-test",
    timestampHeader: timestamp,
    signatureHeader: signature,
    rawBody: Buffer.from('{"eventId":"evt-2"}'),
    nowSeconds: Number(timestamp),
  });
  assert.deepEqual(altered, { valid: false, reason: "invalid_signature" });

  const stale = verifyProviderSignature({
    configuredProviderId: "provider-test",
    configuredSecret: secret,
    providerIdHeader: "provider-test",
    timestampHeader: timestamp,
    signatureHeader: signature,
    rawBody,
    nowSeconds: Number(timestamp) + 301,
  });
  assert.deepEqual(stale, {
    valid: false,
    reason: "timestamp_outside_window",
  });
});
