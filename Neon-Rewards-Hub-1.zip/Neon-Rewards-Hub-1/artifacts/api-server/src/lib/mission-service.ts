import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import {
  missionAttemptsTable,
  missionListingsTable,
} from "@workspace/db/schema";
import { getDatabase } from "./database";

export class MissionUnavailableError extends Error {
  constructor() {
    super("This provider-backed mission is not available.");
    this.name = "MissionUnavailableError";
  }
}

export async function startMissionAttempt(
  trustedUserId: string,
  missionId: string,
): Promise<{ attemptId: string; attemptRef: string }> {
  const database = await getDatabase();
  if (!database) throw new Error("Database is not configured.");

  return database.transaction(async (transaction) => {
    const [mission] = await transaction
      .select({ id: missionListingsTable.id })
      .from(missionListingsTable)
      .where(
        and(
          eq(missionListingsTable.id, missionId),
          eq(missionListingsTable.isActive, true),
          eq(missionListingsTable.isDemo, false),
        ),
      )
      .for("update");

    if (!mission) throw new MissionUnavailableError();

    const attemptRef = randomUUID();
    const [attempt] = await transaction
      .insert(missionAttemptsTable)
      .values({
        userId: trustedUserId,
        missionId: mission.id,
        providerAttemptRef: attemptRef,
        state: "started",
        startedAt: new Date(),
      })
      .returning({ id: missionAttemptsTable.id });

    return { attemptId: attempt.id, attemptRef };
  });
}

export async function submitMissionAttemptForVerification(
  trustedUserId: string,
  attemptId: string,
): Promise<boolean> {
  const database = await getDatabase();
  if (!database) throw new Error("Database is not configured.");

  const [attempt] = await database
    .update(missionAttemptsTable)
    .set({
      state: "pending_verification",
      submittedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(missionAttemptsTable.id, attemptId),
        eq(missionAttemptsTable.userId, trustedUserId),
        eq(missionAttemptsTable.state, "started"),
      ),
    )
    .returning({ id: missionAttemptsTable.id });

  return Boolean(attempt);
}
