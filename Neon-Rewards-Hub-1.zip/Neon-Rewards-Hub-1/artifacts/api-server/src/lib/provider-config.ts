export type ProviderConfiguration = {
  providerId: string;
  webhookSecret: string;
};

export function readProviderConfiguration(
  environment: NodeJS.ProcessEnv = process.env,
): ProviderConfiguration | null {
  const providerId = environment.REWARD_PROVIDER_ID?.trim();
  const webhookSecret = environment.REWARD_PROVIDER_WEBHOOK_SECRET;

  if (!providerId || !webhookSecret || webhookSecret.length < 32) {
    return null;
  }

  return { providerId, webhookSecret };
}
