import { createHmac, timingSafeEqual } from "node:crypto";

export type ProviderSignatureInput = {
  configuredProviderId: string;
  configuredSecret: string;
  providerIdHeader: string | undefined;
  timestampHeader: string | undefined;
  signatureHeader: string | undefined;
  rawBody: Buffer;
  nowSeconds?: number;
};

export type ProviderSignatureResult =
  | { valid: true; timestamp: number }
  | {
      valid: false;
      reason:
        | "provider_mismatch"
        | "invalid_timestamp"
        | "timestamp_outside_window"
        | "invalid_signature";
    };

const MAX_CLOCK_SKEW_SECONDS = 5 * 60;

export function signProviderPayload(
  secret: string,
  timestamp: string,
  rawBody: Buffer,
): string {
  return `sha256=${createHmac("sha256", secret)
    .update(timestamp)
    .update(".")
    .update(rawBody)
    .digest("hex")}`;
}

export function verifyProviderSignature(
  input: ProviderSignatureInput,
): ProviderSignatureResult {
  if (input.providerIdHeader !== input.configuredProviderId) {
    return { valid: false, reason: "provider_mismatch" };
  }

  if (!input.timestampHeader || !/^\d{10}$/.test(input.timestampHeader)) {
    return { valid: false, reason: "invalid_timestamp" };
  }
  if (!input.signatureHeader) {
    return { valid: false, reason: "invalid_signature" };
  }

  const timestamp = Number(input.timestampHeader);
  const nowSeconds = input.nowSeconds ?? Math.floor(Date.now() / 1000);
  if (Math.abs(nowSeconds - timestamp) > MAX_CLOCK_SKEW_SECONDS) {
    return { valid: false, reason: "timestamp_outside_window" };
  }

  const match = /^sha256=([a-fA-F0-9]{64})$/.exec(input.signatureHeader);
  if (!match) return { valid: false, reason: "invalid_signature" };

  const expected = Buffer.from(
    signProviderPayload(
      input.configuredSecret,
      input.timestampHeader,
      input.rawBody,
    ).slice("sha256=".length),
    "hex",
  );
  const received = Buffer.from(match[1], "hex");

  if (
    expected.length !== received.length ||
    !timingSafeEqual(expected, received)
  ) {
    return { valid: false, reason: "invalid_signature" };
  }

  return { valid: true, timestamp };
}
