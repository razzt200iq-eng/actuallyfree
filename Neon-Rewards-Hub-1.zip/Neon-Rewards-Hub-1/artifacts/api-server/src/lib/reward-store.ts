import { and, eq } from "drizzle-orm";
import {
  missionAttemptsTable,
  missionListingsTable,
  pointsLedgerTable,
  rewardEventsTable,
} from "@workspace/db/schema";
import { getDatabase } from "./database";
import type { RewardStore, RewardTransaction } from "./reward-engine";

export async function createDatabaseRewardStore(): Promise<RewardStore | null> {
  const database = await getDatabase();
  if (!database) return null;

  return {
    transaction: async <T>(
      operation: (transaction: RewardTransaction) => Promise<T>,
    ): Promise<T> =>
      database.transaction(async (transaction) => {
        const rewardTransaction: RewardTransaction = {
          claimEvent: async (event) => {
            const [inserted] = await transaction
              .insert(rewardEventsTable)
              .values({
                providerId: event.providerId,
                providerEventId: event.eventId,
                attemptRef: event.attemptRef,
                outcome: event.outcome,
                status: "received",
              })
              .onConflictDoNothing({
                target: [
                  rewardEventsTable.providerId,
                  rewardEventsTable.providerEventId,
                ],
              })
              .returning({ id: rewardEventsTable.id });
            return inserted?.id ?? null;
          },
          getAttemptForUpdate: async (attemptRef) => {
            const [row] = await transaction
              .select({
                attemptId: missionAttemptsTable.id,
                userId: missionAttemptsTable.userId,
                state: missionAttemptsTable.state,
                providerId: missionListingsTable.providerId,
                rewardPoints: missionListingsTable.rewardPoints,
                isDemo: missionListingsTable.isDemo,
                isActive: missionListingsTable.isActive,
              })
              .from(missionAttemptsTable)
              .innerJoin(
                missionListingsTable,
                eq(missionAttemptsTable.missionId, missionListingsTable.id),
              )
              .where(
                and(
                  eq(missionAttemptsTable.providerAttemptRef, attemptRef),
                ),
              )
              .for("update", { of: missionAttemptsTable });

            if (!row) return null;
            return {
              attemptId: row.attemptId,
              userId: row.userId,
              state: row.state,
              mission: {
                providerId: row.providerId,
                rewardPoints: row.rewardPoints,
                isDemo: row.isDemo,
                isActive: row.isActive,
              },
            };
          },
          setAttemptState: async (attemptId, state) => {
            const timestamp = new Date();
            await transaction
              .update(missionAttemptsTable)
              .set({
                state,
                ...(state === "verified" ? { verifiedAt: timestamp } : {}),
                ...(state === "rejected" ? { rejectedAt: timestamp } : {}),
                updatedAt: timestamp,
              })
              .where(eq(missionAttemptsTable.id, attemptId));
          },
          setEventStatus: async (eventRecordId, status, context) => {
            await transaction
              .update(rewardEventsTable)
              .set({
                status,
                processedAt: new Date(),
                ...(context
                  ? { attemptId: context.attemptId, userId: context.userId }
                  : {}),
              })
              .where(eq(rewardEventsTable.id, eventRecordId));
          },
          insertLedgerEntry: async (entry) => {
            await transaction.insert(pointsLedgerTable).values(entry);
          },
        };

        return operation(rewardTransaction);
      }),
  };
}
