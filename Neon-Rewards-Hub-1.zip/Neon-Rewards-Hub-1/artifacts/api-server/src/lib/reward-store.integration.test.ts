import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import test from "node:test";
import { eq } from "drizzle-orm";
import {
  missionAttemptsTable,
  missionListingsTable,
  pointsLedgerTable,
  rewardEventsTable,
  usersTable,
  withdrawalRequestsTable,
} from "@workspace/db/schema";
import { getDatabase } from "./database";
import {
  calculatePointsBalance,
  processProviderRewardEvent,
} from "./reward-engine";
import { createDatabaseRewardStore } from "./reward-store";
import {
  InsufficientPointsError,
  requestWithdrawal,
  resolveWithdrawal,
} from "./withdrawal-service";

test(
  "PostgreSQL stores a signed reward event and ledger credit only once",
  { skip: !process.env.DATABASE_URL },
  async (t) => {
    const database = await getDatabase();
    assert.ok(database, "configured development database should be available");
    const store = await createDatabaseRewardStore();
    assert.ok(store);

    const suffix = randomUUID();
    const userId = randomUUID();
    const missionId = randomUUID();
    const attemptId = randomUUID();
    const providerId = `test-provider-${suffix}`;
    const providerEventId = `test-event-${suffix}`;
    const attemptRef = randomUUID();

    t.after(async () => {
      await database
        .delete(pointsLedgerTable)
        .where(eq(pointsLedgerTable.userId, userId));
      await database
        .delete(rewardEventsTable)
        .where(eq(rewardEventsTable.providerId, providerId));
      await database
        .delete(missionAttemptsTable)
        .where(eq(missionAttemptsTable.userId, userId));
      await database
        .delete(missionListingsTable)
        .where(eq(missionListingsTable.id, missionId));
      await database
        .delete(withdrawalRequestsTable)
        .where(eq(withdrawalRequestsTable.userId, userId));
      await database.delete(usersTable).where(eq(usersTable.id, userId));
    });

    await database.insert(usersTable).values({
      id: userId,
      authProvider: "test",
      authSubject: suffix,
    });
    await database.insert(missionListingsTable).values({
      id: missionId,
      providerId,
      providerOfferId: `offer-${suffix}`,
      kind: "mission",
      title: "Temporary integration fixture",
      description: "Deleted by the test cleanup hook.",
      durationMinutes: 1,
      rewardPoints: 23,
      requirements: [],
      isDemo: false,
      isActive: true,
      providerVerifiedAt: new Date(),
    });
    await database.insert(missionAttemptsTable).values({
      id: attemptId,
      userId,
      missionId,
      providerAttemptRef: attemptRef,
      state: "pending_verification",
    });

    const event = {
      providerId,
      eventId: providerEventId,
      attemptRef,
      outcome: "verified" as const,
    };
    const first = await processProviderRewardEvent(event, store);
    const duplicate = await processProviderRewardEvent(event, store);
    const ledgerRows = await database
      .select({
        eventId: pointsLedgerTable.eventId,
        direction: pointsLedgerTable.direction,
        amountPoints: pointsLedgerTable.amountPoints,
      })
      .from(pointsLedgerTable)
      .where(eq(pointsLedgerTable.userId, userId));

    assert.deepEqual(first, { status: "applied", pointsCredited: 23 });
    assert.deepEqual(duplicate, { status: "duplicate", pointsCredited: 0 });
    assert.equal(ledgerRows.length, 1);
    assert.equal(ledgerRows[0]?.amountPoints, 23);

    const withdrawalKey = `withdrawal-${suffix}`;
    const withdrawal = await requestWithdrawal(userId, 10, withdrawalKey);
    const duplicateWithdrawal = await requestWithdrawal(
      userId,
      10,
      withdrawalKey,
    );
    assert.equal(withdrawal.duplicate, false);
    assert.equal(duplicateWithdrawal.duplicate, true);

    const afterDebit = await database
      .select({
        direction: pointsLedgerTable.direction,
        amountPoints: pointsLedgerTable.amountPoints,
      })
      .from(pointsLedgerTable)
      .where(eq(pointsLedgerTable.userId, userId));
    assert.equal(calculatePointsBalance(afterDebit), 13);

    await assert.rejects(
      requestWithdrawal(userId, 100, `too-large-${suffix}`),
      InsufficientPointsError,
    );

    const rejected = await resolveWithdrawal(
      userId,
      withdrawal.request.id,
      "rejected",
    );
    const duplicateResolution = await resolveWithdrawal(
      userId,
      withdrawal.request.id,
      "rejected",
    );
    assert.equal(rejected.duplicate, false);
    assert.equal(duplicateResolution.duplicate, true);

    const afterRefund = await database
      .select({
        direction: pointsLedgerTable.direction,
        amountPoints: pointsLedgerTable.amountPoints,
      })
      .from(pointsLedgerTable)
      .where(eq(pointsLedgerTable.userId, userId));
    assert.equal(calculatePointsBalance(afterRefund), 23);
  },
);
