import { and, eq } from "drizzle-orm";
import {
  pointsLedgerTable,
  usersTable,
  withdrawalRequestsTable,
} from "@workspace/db/schema";
import { getDatabase } from "./database";
import { calculatePointsBalance } from "./reward-engine";

export class InsufficientPointsError extends Error {
  constructor() {
    super("The available points balance is too low for this withdrawal.");
    this.name = "InsufficientPointsError";
  }
}

export class InvalidWithdrawalError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "InvalidWithdrawalError";
  }
}

export async function requestWithdrawal(
  trustedUserId: string,
  amountPoints: number,
  idempotencyKey: string,
): Promise<{
  request: typeof withdrawalRequestsTable.$inferSelect;
  duplicate: boolean;
}> {
  if (!Number.isSafeInteger(amountPoints) || amountPoints <= 0) {
    throw new InvalidWithdrawalError("Withdrawal points must be a positive integer.");
  }
  if (idempotencyKey.length < 8 || idempotencyKey.length > 160) {
    throw new InvalidWithdrawalError("A valid idempotency key is required.");
  }

  const database = await getDatabase();
  if (!database) throw new Error("Database is not configured.");

  return database.transaction(async (transaction) => {
    const [user] = await transaction
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.id, trustedUserId))
      .for("update");
    if (!user) throw new InvalidWithdrawalError("User was not found.");

    const [existing] = await transaction
      .select()
      .from(withdrawalRequestsTable)
      .where(
        and(
          eq(withdrawalRequestsTable.userId, trustedUserId),
          eq(withdrawalRequestsTable.idempotencyKey, idempotencyKey),
        ),
      )
      .limit(1);
    if (existing) {
      if (existing.amountPoints !== amountPoints) {
        throw new InvalidWithdrawalError(
          "An idempotency key cannot be reused with a different amount.",
        );
      }
      return { request: existing, duplicate: true };
    }

    const ledgerEntries = await transaction
      .select({
        direction: pointsLedgerTable.direction,
        amountPoints: pointsLedgerTable.amountPoints,
      })
      .from(pointsLedgerTable)
      .where(eq(pointsLedgerTable.userId, trustedUserId));
    const availablePoints = calculatePointsBalance(ledgerEntries);
    if (amountPoints > availablePoints) throw new InsufficientPointsError();

    const [request] = await transaction
      .insert(withdrawalRequestsTable)
      .values({
        userId: trustedUserId,
        idempotencyKey,
        amountPoints,
        status: "requested",
      })
      .returning();

    await transaction.insert(pointsLedgerTable).values({
      eventId: `withdrawal:${request.id}`,
      userId: trustedUserId,
      direction: "debit",
      amountPoints,
      source: "withdrawal_request",
      sourceId: request.id,
    });

    return { request, duplicate: false };
  });
}

export async function resolveWithdrawal(
  trustedUserId: string,
  withdrawalId: string,
  nextStatus: "approved" | "paid" | "rejected" | "cancelled",
): Promise<{
  request: typeof withdrawalRequestsTable.$inferSelect;
  duplicate: boolean;
}> {
  const database = await getDatabase();
  if (!database) throw new Error("Database is not configured.");

  return database.transaction(async (transaction) => {
    const [request] = await transaction
      .select()
      .from(withdrawalRequestsTable)
      .where(
        and(
          eq(withdrawalRequestsTable.id, withdrawalId),
          eq(withdrawalRequestsTable.userId, trustedUserId),
        ),
      )
      .for("update");
    if (!request) throw new InvalidWithdrawalError("Withdrawal was not found.");
    if (request.status === nextStatus) {
      return { request, duplicate: true };
    }

    const canApprove = nextStatus === "approved" && request.status === "requested";
    const canPay = nextStatus === "paid" && request.status === "approved";
    const canReverse =
      (nextStatus === "rejected" || nextStatus === "cancelled") &&
      (request.status === "requested" || request.status === "approved");
    if (!canApprove && !canPay && !canReverse) {
      throw new InvalidWithdrawalError("This withdrawal state transition is not allowed.");
    }

    if (canReverse) {
      await transaction.insert(pointsLedgerTable).values({
        eventId: `withdrawal-refund:${request.id}`,
        userId: trustedUserId,
        direction: "credit",
        amountPoints: request.amountPoints,
        source: "withdrawal_refund",
        sourceId: request.id,
      });
    }

    const [updated] = await transaction
      .update(withdrawalRequestsTable)
      .set({ status: nextStatus, updatedAt: new Date() })
      .where(eq(withdrawalRequestsTable.id, request.id))
      .returning();
    return { request: updated, duplicate: false };
  });
}
