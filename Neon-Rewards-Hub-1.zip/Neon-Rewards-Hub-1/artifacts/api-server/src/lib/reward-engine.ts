export type ProviderRewardOutcome = "verified" | "rejected";
export type MissionProgressState =
  | "available"
  | "started"
  | "pending_verification"
  | "verified"
  | "rejected";

export type ProviderRewardEvent = {
  providerId: string;
  eventId: string;
  attemptRef: string;
  outcome: ProviderRewardOutcome;
};

export type AttemptRewardContext = {
  attemptId: string;
  userId: string;
  state: MissionProgressState;
  mission: {
    providerId: string | null;
    rewardPoints: number;
    isDemo: boolean;
    isActive: boolean;
  };
};

export type LedgerEntryInput = {
  eventId: string;
  userId: string;
  direction: "credit" | "debit";
  amountPoints: number;
  source:
    | "verified_provider_event"
    | "withdrawal_request"
    | "withdrawal_refund";
  sourceId: string;
};

export type RewardTransaction = {
  claimEvent(event: ProviderRewardEvent): Promise<string | null>;
  getAttemptForUpdate(attemptRef: string): Promise<AttemptRewardContext | null>;
  setAttemptState(
    attemptId: string,
    state: MissionProgressState,
  ): Promise<void>;
  setEventStatus(
    eventRecordId: string,
    status: "applied" | "rejected",
    context?: { attemptId: string; userId: string },
  ): Promise<void>;
  insertLedgerEntry(entry: LedgerEntryInput): Promise<void>;
};

export type RewardStore = {
  transaction<T>(operation: (transaction: RewardTransaction) => Promise<T>): Promise<T>;
};

export type RewardProcessingResult = {
  status: "applied" | "duplicate" | "rejected";
  pointsCredited: number;
};

export async function processProviderRewardEvent(
  event: ProviderRewardEvent,
  store: RewardStore,
): Promise<RewardProcessingResult> {
  return store.transaction(async (transaction) => {
    const eventRecordId = await transaction.claimEvent(event);
    if (!eventRecordId) {
      return { status: "duplicate", pointsCredited: 0 };
    }

    const attempt = await transaction.getAttemptForUpdate(event.attemptRef);
    if (
      !attempt ||
      attempt.state !== "pending_verification" ||
      attempt.mission.isDemo ||
      !attempt.mission.isActive ||
      attempt.mission.providerId !== event.providerId
    ) {
      await transaction.setEventStatus(eventRecordId, "rejected");
      return { status: "rejected", pointsCredited: 0 };
    }

    if (event.outcome === "rejected") {
      await transaction.setAttemptState(attempt.attemptId, "rejected");
      await transaction.setEventStatus(eventRecordId, "rejected", {
        attemptId: attempt.attemptId,
        userId: attempt.userId,
      });
      return { status: "rejected", pointsCredited: 0 };
    }

    const rewardPoints = attempt.mission.rewardPoints;
    if (!Number.isSafeInteger(rewardPoints) || rewardPoints <= 0) {
      await transaction.setEventStatus(eventRecordId, "rejected", {
        attemptId: attempt.attemptId,
        userId: attempt.userId,
      });
      return { status: "rejected", pointsCredited: 0 };
    }

    await transaction.setAttemptState(attempt.attemptId, "verified");
    await transaction.insertLedgerEntry({
      eventId: eventRecordId,
      userId: attempt.userId,
      direction: "credit",
      amountPoints: rewardPoints,
      source: "verified_provider_event",
      sourceId: eventRecordId,
    });
    await transaction.setEventStatus(eventRecordId, "applied", {
      attemptId: attempt.attemptId,
      userId: attempt.userId,
    });

    return { status: "applied", pointsCredited: rewardPoints };
  });
}

export function calculatePointsBalance(
  entries: ReadonlyArray<Pick<LedgerEntryInput, "direction" | "amountPoints">>,
): number {
  return entries.reduce((balance, entry) => {
    if (!Number.isSafeInteger(entry.amountPoints) || entry.amountPoints <= 0) {
      throw new Error("Ledger entries must contain positive integer points.");
    }
    return balance + (entry.direction === "credit" ? entry.amountPoints : -entry.amountPoints);
  }, 0);
}
