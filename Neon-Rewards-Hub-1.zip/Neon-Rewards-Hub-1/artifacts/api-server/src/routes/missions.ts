import { and, asc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ListMissionListingsResponse } from "@workspace/api-zod";
import { missionListingsTable } from "@workspace/db/schema";
import { getDatabase } from "../lib/database";

const router: IRouter = Router();

router.get("/missions", async (req, res): Promise<void> => {
  const database = await getDatabase();
  if (!database) {
    res.status(503).json({ error: "DATABASE_NOT_CONFIGURED" });
    return;
  }

  try {
    const listings = await database
      .select({
        id: missionListingsTable.id,
        kind: missionListingsTable.kind,
        title: missionListingsTable.title,
        description: missionListingsTable.description,
        category: missionListingsTable.category,
        durationMinutes: missionListingsTable.durationMinutes,
        rewardPoints: missionListingsTable.rewardPoints,
        requirements: missionListingsTable.requirements,
        isDemo: missionListingsTable.isDemo,
      })
      .from(missionListingsTable)
      .where(
        and(
          eq(missionListingsTable.isActive, true),
          eq(missionListingsTable.isDemo, false),
        ),
      )
      .orderBy(asc(missionListingsTable.createdAt));

    const data = ListMissionListingsResponse.parse({
      missions: listings.map((listing) => ({
        ...listing,
        status: "available",
      })),
    });
    res.setHeader("Cache-Control", "no-store");
    res.json(data);
  } catch (error) {
    const errorCode =
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      typeof error.code === "string"
        ? error.code
        : "unknown";
    req.log.warn({ errorCode }, "Mission catalog query failed");
    res.status(503).json({ error: "MISSION_CATALOG_UNAVAILABLE" });
  }
});

export default router;
