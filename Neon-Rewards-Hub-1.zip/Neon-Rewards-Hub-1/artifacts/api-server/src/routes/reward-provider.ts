import { Router, type IRouter, type Request } from "express";
import {
  ReceiveRewardProviderCallbackBody,
  ReceiveRewardProviderCallbackResponse,
} from "@workspace/api-zod";
import { getDatabase } from "../lib/database";
import { readProviderConfiguration } from "../lib/provider-config";
import { verifyProviderSignature } from "../lib/provider-signature";
import { processProviderRewardEvent } from "../lib/reward-engine";
import { createDatabaseRewardStore } from "../lib/reward-store";

type RequestWithRawBody = Request & { rawBody?: Buffer };
const router: IRouter = Router();

router.post("/reward-provider/callback", async (req, res): Promise<void> => {
  const providerConfiguration = readProviderConfiguration();
  if (!providerConfiguration) {
    res.status(503).json({ error: "REWARD_PROVIDER_NOT_CONFIGURED" });
    return;
  }

  const rawBody = (req as RequestWithRawBody).rawBody;
  if (!rawBody || rawBody.length === 0) {
    res.status(400).json({ error: "CALLBACK_BODY_REQUIRED" });
    return;
  }

  const signature = verifyProviderSignature({
    configuredProviderId: providerConfiguration.providerId,
    configuredSecret: providerConfiguration.webhookSecret,
    providerIdHeader: req.header("X-ActuallyFree-Provider"),
    timestampHeader: req.header("X-ActuallyFree-Timestamp"),
    signatureHeader: req.header("X-ActuallyFree-Signature"),
    rawBody,
  });

  if (!signature.valid) {
    req.log.warn({ reason: signature.reason }, "Reward callback signature rejected");
    res.status(401).json({ error: "INVALID_PROVIDER_SIGNATURE" });
    return;
  }

  let rawEvent: unknown;
  try {
    rawEvent = JSON.parse(rawBody.toString("utf8"));
  } catch {
    res.status(400).json({ error: "INVALID_CALLBACK_JSON" });
    return;
  }

  const parsedEvent = ReceiveRewardProviderCallbackBody.strict().safeParse(
    rawEvent,
  );
  if (!parsedEvent.success) {
    req.log.warn("Reward callback body failed validation");
    res.status(400).json({ error: "INVALID_REWARD_EVENT" });
    return;
  }

  const database = await getDatabase();
  if (!database) {
    res.status(503).json({ error: "DATABASE_NOT_CONFIGURED" });
    return;
  }

  const store = await createDatabaseRewardStore();
  if (!store) {
    res.status(503).json({ error: "DATABASE_NOT_CONFIGURED" });
    return;
  }

  try {
    const result = await processProviderRewardEvent(
      {
        providerId: providerConfiguration.providerId,
        eventId: parsedEvent.data.eventId,
        attemptRef: parsedEvent.data.attemptRef,
        outcome: parsedEvent.data.outcome,
      },
      store,
    );
    res.json(ReceiveRewardProviderCallbackResponse.parse(result));
  } catch (error) {
    const errorCode =
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      typeof error.code === "string"
        ? error.code
        : "unknown";
    req.log.error({ errorCode }, "Reward event processing failed");
    res.status(503).json({ error: "REWARD_EVENT_PROCESSING_UNAVAILABLE" });
  }
});

export default router;
