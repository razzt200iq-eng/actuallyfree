import { Router, type IRouter } from "express";
import healthRouter from "./health";
import missionsRouter from "./missions";
import rewardProviderRouter from "./reward-provider";
import systemRouter from "./system";

const router: IRouter = Router();

router.use(healthRouter);
router.use(systemRouter);
router.use(missionsRouter);
router.use(rewardProviderRouter);

export default router;
