import { Router, type IRouter } from "express";
import { GetSystemStatusResponse } from "@workspace/api-zod";
import { getDatabaseState } from "../lib/database";
import { readProviderConfiguration } from "../lib/provider-config";

const router: IRouter = Router();

function getAccountAuthState(): "not_configured" | "configured" {
  return "not_configured";
}

router.get("/system/status", async (_req, res): Promise<void> => {
  const [databaseState, providerConfiguration] = await Promise.all([
    getDatabaseState(),
    Promise.resolve(readProviderConfiguration()),
  ]);

  // Account-scoped actions remain disabled until a trusted login provider is
  // integrated. A session secret alone is not an identity provider.
  const accountAuthState = getAccountAuthState();
  const realRewardsEnabled = false;
  const providerConfigured = providerConfiguration !== null;

  const data = GetSystemStatusResponse.parse({
    overallState:
      databaseState === "connected" &&
      providerConfigured &&
      accountAuthState === "configured"
        ? "ready"
        : "setup_required",
    databaseState,
    rewardProviderState: providerConfigured
      ? "credentials_configured"
      : "not_configured",
    accountAuthState,
    realRewardsEnabled,
  });

  res.setHeader("Cache-Control", "no-store");
  res.json(data);
});

export default router;
