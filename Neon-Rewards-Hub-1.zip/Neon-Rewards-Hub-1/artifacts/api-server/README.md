# ActuallyFree backend setup

The API service uses the workspace PostgreSQL database through Drizzle. The
schema includes users, provider-backed mission listings, mission attempts,
provider reward events, an append-only points ledger, and withdrawal requests.
No demo listings or demo points are seeded into the database.

## Current readiness

- The Replit-managed development database is present as `DATABASE_URL`.
- No reward-provider ID or webhook signing secret is configured.
- Account authentication is not integrated. `SESSION_SECRET` by itself does not
  identify a user, so account-scoped routes and real reward credits remain
  disabled.

The web app reads `GET /api/system/status` and displays these states. A missing
or unreachable database is reported explicitly; it is not presented as an
operational backend.

## Database

For the current Replit-managed PostgreSQL database, Replit supplies
`DATABASE_URL` to the server. Do not add or copy that managed value manually.
The schema is in `lib/db/src/schema/` and development schema changes use:

```sh
pnpm --filter @workspace/db run push
```

If you intentionally replace the managed database with an external PostgreSQL
service, configure its connection string as a server-side secret named
`DATABASE_URL`; never expose it through a `VITE_` variable or browser code.

## Reward provider configuration

The current code implements a provider-neutral signed-callback protocol; it
does not connect to a specific provider or import any live offers. Configure:

- `REWARD_PROVIDER_ID` — a non-secret environment variable identifying the
  provider whose callbacks this deployment accepts.
- `REWARD_PROVIDER_WEBHOOK_SECRET` — a server-side secret containing the
  provider-issued HMAC-SHA256 signing secret. It must be at least 32 characters.

The provider must sign the exact raw request body using
`HMAC-SHA256(secret, timestamp + "." + rawBody)` and send:

- `X-ActuallyFree-Provider`
- `X-ActuallyFree-Timestamp` (Unix seconds; accepted within five minutes)
- `X-ActuallyFree-Signature` (`sha256=` followed by the hex digest)

If a chosen provider uses a different signature format or event payload, write
and review a provider-specific adapter before setting these values. Supplying a
secret alone does not establish provider legitimacy.

The callback body contains only `eventId`, `attemptRef`, and `outcome`; it
cannot choose the reward amount. The server credits the stored listing's points
only when the signed event is unique, the attempt is pending verification, the
listing is active and non-demo, and its provider matches the configured
provider. Invalid callbacks are rejected without a credit.

## Security boundary and unfinished integrations

There is intentionally no public endpoint that accepts a client-supplied user
ID. Attempt-service methods require a trusted user ID from a future
authentication middleware. Before account-specific starts, balances, or
withdrawal actions are exposed, integrate a real sign-in provider and resolve
its stable subject to `actuallyfree_users`.

Withdrawal requests and ledger debit/refund sources are modeled in the
database, but no redemption or payout flow is enabled. The ledger is the
authoritative balance source; demo UI points never enter it.
