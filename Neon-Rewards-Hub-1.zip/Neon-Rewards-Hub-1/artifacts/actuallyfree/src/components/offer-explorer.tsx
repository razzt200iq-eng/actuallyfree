import { useMemo, useState } from 'react';
import {
  ArrowRight,
  BarChart3,
  Check,
  Clock3,
  Gift,
  Info,
  Search,
  ShieldCheck,
  Target,
  WifiOff,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

type OfferPage = 'missions' | 'surveys';

type DemoOffer = {
  id: string;
  title: string;
  category: string;
  description: string;
  duration: string;
  demoRewardPoints: number;
  requirements: string[];
};

const demoOffers: Record<OfferPage, DemoOffer[]> = {
  missions: [
    {
      id: 'mission-discover',
      title: 'Discover a player-made experience',
      category: 'Explore',
      description: 'A sample discovery task showing how a partner activity could be presented.',
      duration: '8–12 min',
      demoRewardPoints: 180,
      requirements: [
        'Example: Review the public experience description.',
        'Example eligibility checks may apply.',
      ],
    },
    {
      id: 'mission-game-mode',
      title: 'Try a featured game mode',
      category: 'Gaming',
      description: 'A sample game activity. No game is launched from this preview.',
      duration: '10–15 min',
      demoRewardPoints: 250,
      requirements: [
        'Example: Explore the listed game mode.',
        'Example: Review partner terms before participating.',
      ],
    },
    {
      id: 'mission-feedback',
      title: 'Share feedback on game discovery',
      category: 'Feedback',
      description: 'A sample feedback task to preview the details players would see.',
      duration: '5–7 min',
      demoRewardPoints: 140,
      requirements: [
        'Example: Answer a short feedback form.',
        'Never provide account passwords.',
      ],
    },
    {
      id: 'mission-community',
      title: 'Review a community event',
      category: 'Community',
      description: 'A sample community listing with an example eligibility checklist.',
      duration: '4–6 min',
      demoRewardPoints: 110,
      requirements: [
        'Example: Read a community event description.',
        'Availability would depend on provider eligibility.',
      ],
    },
  ],
  surveys: [
    {
      id: 'survey-player-pulse',
      title: 'Player experience pulse',
      category: 'Feedback',
      description: 'A sample opinion survey about game discovery experiences.',
      duration: '4–6 min',
      demoRewardPoints: 90,
      requirements: [
        'Example: Answer general experience questions.',
        'This demo does not collect or submit responses.',
      ],
    },
    {
      id: 'survey-gaming-habits',
      title: 'Gaming preferences snapshot',
      category: 'Gaming',
      description: 'A sample survey card with a short, clearly stated time estimate.',
      duration: '6–8 min',
      demoRewardPoints: 150,
      requirements: [
        'Example: Share broad game preferences.',
        'Do not enter passwords or account credentials.',
      ],
    },
    {
      id: 'survey-creator-content',
      title: 'Creator content preferences',
      category: 'Creators',
      description: 'A sample survey about the types of creator content players enjoy.',
      duration: '5–7 min',
      demoRewardPoints: 120,
      requirements: [
        'Example: Choose from sample content topics.',
        'This demo does not collect or submit responses.',
      ],
    },
    {
      id: 'survey-play-routines',
      title: 'Digital play routines',
      category: 'Preferences',
      description: 'A sample card demonstrating a survey with its requirements shown upfront.',
      duration: '7–10 min',
      demoRewardPoints: 200,
      requirements: [
        'Example: Answer broad, non-sensitive preference questions.',
        'Provider eligibility would be shown before participation.',
      ],
    },
  ],
};

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

export function OfferExplorer({ page }: { page: OfferPage }) {
  const offers = demoOffers[page];
  const isMissionPage = page === 'missions';
  const PageIcon = isMissionPage ? Target : BarChart3;
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [selectedOffer, setSelectedOffer] = useState<DemoOffer | null>(null);
  const [previewOpened, setPreviewOpened] = useState<Record<string, boolean>>({});

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(offers.map((offer) => offer.category)))],
    [offers],
  );

  const filteredOffers = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();
    return offers.filter((offer) => {
      const matchesCategory = category === 'All' || offer.category === category;
      const searchableText = [
        offer.title,
        offer.category,
        offer.description,
        ...offer.requirements,
      ]
        .join(' ')
        .toLowerCase();
      return matchesCategory && (!normalizedSearch || searchableText.includes(normalizedSearch));
    });
  }, [category, offers, search]);

  const selectedPreviewWasOpened = selectedOffer
    ? Boolean(previewOpened[selectedOffer.id])
    : false;

  function clearFilters() {
    setSearch('');
    setCategory('All');
  }

  function openPreview() {
    if (!selectedOffer) return;
    setPreviewOpened((current) => ({ ...current, [selectedOffer.id]: true }));
  }

  return (
    <>
      <div className="flex items-start justify-between gap-4 mb-7">
        <div>
          <div className="eyebrow mb-3">DISCOVERY / {isMissionPage ? '02' : '03'}</div>
          <h1 className="page-title">{isMissionPage ? 'Missions' : 'Surveys'}</h1>
          <p className="text-sm text-[#9695a8] mt-3 max-w-xl">
            {isMissionPage
              ? 'Browse example missions and review each task before opening its preview.'
              : 'Browse example surveys with sample requirements and time estimates upfront.'}
          </p>
        </div>
        <span className="hidden sm:grid w-12 h-12 rounded-2xl bg-[#282438] text-[#b09aff] place-items-center">
          <PageIcon size={21} />
        </span>
      </div>

      <div className="notice flex items-start gap-3 px-4 py-4 mb-5">
        <Info size={16} className="text-[#a991ff] shrink-0 mt-0.5" />
        <div>
          <p className="text-xs font-extrabold text-[#e0d8f4]">
            DEMO DATA — NOT LIVE OR CLAIMABLE
          </p>
          <p className="text-[11px] leading-relaxed mt-1 text-[#aaa3bb]">
            Every offer, duration, requirement, status, and point amount below is an example.
            Providers are not connected. Starting a preview does not launch a task, submit
            information, record completion, or add points.
          </p>
        </div>
      </div>

      <section className="panel p-4 sm:p-5 mb-5" aria-label={`${isMissionPage ? 'Mission' : 'Survey'} search and filters`}>
        <label htmlFor={`offer-search-${page}`} className="eyebrow block mb-2">
          Search {isMissionPage ? 'missions' : 'surveys'}
        </label>
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#7f7e92]" />
          <input
            id={`offer-search-${page}`}
            type="search"
            value={search}
            onChange={(event) => setSearch(event.currentTarget.value)}
            placeholder="Search title, category, or requirements"
            className="w-full rounded-xl border border-[#333343] bg-[#14141d] py-3 pl-10 pr-10 text-xs text-[#e9e6f1] placeholder:text-[#717184] focus:border-[#9b82ef] focus:outline-none focus:ring-2 focus:ring-[#9b82ef]/20"
            data-testid={`input-search-${page}`}
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8d8ba0] hover:text-white"
              data-testid={`button-clear-search-${page}`}
            >
              <span className="sr-only">Clear search</span>
              ×
            </button>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2" role="group" aria-label="Filter by category">
          <span className="eyebrow mr-1">Category</span>
          {categories.map((item) => {
            const active = category === item;
            return (
              <button
                key={item}
                type="button"
                onClick={() => setCategory(item)}
                aria-pressed={active}
                className={`rounded-full border px-3 py-1.5 text-[10px] font-bold transition-colors ${
                  active
                    ? 'border-[#8d77dd]/60 bg-[#735dc0]/20 text-[#d2c5ff]'
                    : 'border-[#333343] bg-[#191922] text-[#9695a8] hover:border-[#5d5680] hover:text-[#e0dced]'
                }`}
                data-testid={`filter-${page}-${slugify(item)}`}
              >
                {item}
              </button>
            );
          })}
        </div>
      </section>

      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <p className="text-[11px] text-[#a3a0b2]" aria-live="polite" data-testid={`results-count-${page}`}>
          {filteredOffers.length} demo {isMissionPage ? 'missions' : 'surveys'}
        </p>
        {(search || category !== 'All') && (
          <button
            type="button"
            className="text-[10px] font-bold text-[#b7a6ff] hover:text-white"
            onClick={clearFilters}
            data-testid={`button-reset-filters-${page}`}
          >
            Clear filters
          </button>
        )}
      </div>

      {filteredOffers.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredOffers.map((offer) => {
            const opened = Boolean(previewOpened[offer.id]);
            return (
              <article
                key={offer.id}
                className="panel flex h-full flex-col p-4 sm:p-5 transition-colors hover:border-[#51466f]"
                data-testid={`offer-card-${offer.id}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="rounded-full border border-[#3d3654] bg-[#272137] px-2.5 py-1 text-[9px] font-bold text-[#c3b3ff]">
                    {offer.category}
                  </span>
                  <span className="inline-flex items-center gap-1 text-[9px] font-extrabold uppercase tracking-[.1em] text-[#e7bd7b]">
                    <Info size={11} /> Demo
                  </span>
                </div>

                <h2 className="mt-4 font-['Space_Grotesk'] text-base font-bold leading-snug text-[#efedf6]">
                  {offer.title}
                </h2>
                <p className="mt-2 min-h-10 text-[11px] leading-relaxed text-[#9695a8]">
                  {offer.description}
                </p>

                <div className="mt-4 grid grid-cols-2 gap-2">
                  <div className="rounded-lg border border-white/[.06] bg-black/10 p-3">
                    <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-wide text-[#848398]">
                      <Clock3 size={12} /> Est. duration
                    </div>
                    <p className="mt-1.5 text-xs font-bold text-[#e5e1ef]">{offer.duration}</p>
                  </div>
                  <div className="rounded-lg border border-white/[.06] bg-black/10 p-3">
                    <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-wide text-[#848398]">
                      <Gift size={12} /> Sample reward
                    </div>
                    <p className="mt-1.5 text-xs font-bold text-[#bbaaff]">
                      {offer.demoRewardPoints} demo pts
                    </p>
                  </div>
                </div>

                <div className="mt-4">
                  <p className="eyebrow mb-2">Example requirements</p>
                  <ul className="space-y-1.5">
                    {offer.requirements.slice(0, 2).map((requirement) => (
                      <li key={requirement} className="flex items-start gap-2 text-[10px] leading-relaxed text-[#9695a8]">
                        <Check size={12} className="mt-0.5 shrink-0 text-[#77cabc]" />
                        <span>{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-auto pt-4">
                  <div className="mb-3 flex items-center justify-between gap-2 border-t border-white/[.06] pt-3">
                    <span className="text-[9px] font-bold uppercase tracking-[.08em] text-[#e7bd7b]">
                      {opened ? 'Preview opened · local only' : 'Status · demo only'}
                    </span>
                    <span className="text-[9px] text-[#77768a]">Not claimable</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedOffer(offer)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#484259] bg-[#211f2d] px-3 py-2.5 text-[10px] font-extrabold text-[#d8d0ed] transition-colors hover:border-[#9b82ef]/60 hover:bg-[#2b263b]"
                    data-testid={`button-details-${offer.id}`}
                  >
                    View details <ArrowRight size={13} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="panel grid min-h-[250px] place-items-center p-8 text-center">
          <div className="max-w-sm">
            <div className="empty-orbit mx-auto mb-4"><Search size={24} /></div>
            <h2 className="font-['Space_Grotesk'] text-lg font-bold">No matching demo listings</h2>
            <p className="mt-2 text-xs leading-relaxed text-[#8c8b9e]">
              Try another search or category. These examples are not live provider offers.
            </p>
            <button
              type="button"
              onClick={clearFilters}
              className="mt-4 rounded-lg border border-[#454056] px-3 py-2 text-[10px] font-bold text-[#d4c9f3] hover:bg-white/[.05]"
              data-testid={`button-empty-reset-${page}`}
            >
              Reset search and filters
            </button>
          </div>
        </div>
      )}

      <div className="mt-5 panel p-5">
        <div className="flex gap-3">
          <ShieldCheck size={17} className="mt-0.5 shrink-0 text-[#79c9b7]" />
          <div>
            <div className="text-xs font-extrabold">Before you participate</div>
            <p className="mt-1 text-[11px] leading-relaxed text-[#8c8b9d]">
              These are examples only. No provider is connected, no task or survey response is
              submitted, and no points are earned. ActuallyFree never asks for your Roblox
              password.
            </p>
          </div>
        </div>
      </div>

      <Dialog
        open={selectedOffer !== null}
        onOpenChange={(open) => {
          if (!open) setSelectedOffer(null);
        }}
      >
        {selectedOffer && (
          <DialogContent className="w-[calc(100%-2rem)] border-[#343343] bg-[#171720] text-[#efedf6] sm:max-w-xl">
            <DialogHeader className="pr-8 text-left">
              <div className="eyebrow text-[#dfb77a]">DEMO LISTING · NOT LIVE</div>
              <DialogTitle className="font-['Space_Grotesk'] text-xl font-bold">
                {selectedOffer.title}
              </DialogTitle>
              <DialogDescription className="text-xs leading-relaxed text-[#9a98aa]">
                {selectedOffer.description}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/[.07] bg-black/10 p-3">
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-wide text-[#8c8a9e]">
                  <Clock3 size={13} /> Estimated duration
                </div>
                <p className="mt-2 text-sm font-bold">{selectedOffer.duration}</p>
              </div>
              <div className="rounded-xl border border-white/[.07] bg-black/10 p-3">
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-wide text-[#8c8a9e]">
                  <Gift size={13} /> Sample reward
                </div>
                <p className="mt-2 text-sm font-bold text-[#bbaaff]">
                  {selectedOffer.demoRewardPoints} demo points
                </p>
              </div>
            </div>

            <section>
              <h3 className="eyebrow mb-2">Example requirements</h3>
              <ul className="space-y-2">
                {selectedOffer.requirements.map((requirement) => (
                  <li key={requirement} className="flex items-start gap-2 text-xs leading-relaxed text-[#b0adbd]">
                    <Check size={14} className="mt-0.5 shrink-0 text-[#77cabc]" />
                    {requirement}
                  </li>
                ))}
              </ul>
            </section>

            <div className="notice flex items-start gap-2.5 p-3">
              <WifiOff size={14} className="mt-0.5 shrink-0 text-[#b39cff]" />
              <p className="text-[10px] leading-relaxed text-[#c2bbd4]">
                This is sample content. The button only opens a local demo state; it does not
                start a provider task, submit a survey, mark anything complete, or add points.
              </p>
            </div>

            {selectedPreviewWasOpened && (
              <p role="status" className="text-[11px] font-semibold text-[#83d0c0]">
                Demo preview opened locally. No task was completed and no points were earned.
              </p>
            )}

            <DialogFooter className="gap-2 sm:flex-row">
              <button
                type="button"
                onClick={() => setSelectedOffer(null)}
                className="rounded-lg border border-[#393847] px-4 py-2.5 text-[10px] font-bold text-[#c2bfce] hover:bg-white/[.05]"
                data-testid="button-close-offer-details"
              >
                Close
              </button>
              <button
                type="button"
                onClick={openPreview}
                disabled={selectedPreviewWasOpened}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#a28aff] px-4 py-2.5 text-[10px] font-extrabold text-[#17131f] transition-colors hover:bg-[#b5a4ff] disabled:cursor-not-allowed disabled:opacity-65"
                data-testid={`button-start-demo-${selectedOffer.id}`}
              >
                {selectedPreviewWasOpened
                  ? 'Demo preview opened'
                  : isMissionPage
                    ? 'Start demo mission'
                    : 'Start demo survey'}
                <ArrowRight size={13} />
              </button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </>
  );
}
