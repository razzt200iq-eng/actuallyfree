import { createContext, useContext, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { Activity, ArrowRight, BadgeCheck, BarChart3, Bell, Check, ChevronRight, CircleHelp, Clock3, Compass, Gamepad2, Gift, Info, LockKeyhole, Menu, Monitor, Moon, Settings, ShieldCheck, Smartphone, Sparkles, Target, Trophy, Wallet, WifiOff } from 'lucide-react';
import { useGetSystemStatus } from '@workspace/api-client-react';
import { OfferExplorer } from '@/components/offer-explorer';

const queryClient = new QueryClient();
type PageId = 'home' | 'missions' | 'surveys' | 'leaderboard' | 'wallet' | 'settings';
type Mode = 'manual' | 'auto';
type Preferences = {
  mode: Mode;
  setMode: (mode: Mode) => void;
  compact: boolean;
  setCompact: (compact: boolean) => void;
  notifications: boolean;
  setNotifications: (notifications: boolean) => void;
};
const PreferencesContext = createContext<Preferences | null>(null);

const navItems: { id: PageId; label: string; href: string; icon: typeof Compass }[] = [
  { id: 'home', label: 'Overview', href: '/', icon: Compass },
  { id: 'missions', label: 'Missions', href: '/missions', icon: Target },
  { id: 'surveys', label: 'Surveys', href: '/surveys', icon: BarChart3 },
  { id: 'leaderboard', label: 'Leaderboard', href: '/leaderboard', icon: Trophy },
  { id: 'wallet', label: 'Wallet', href: '/wallet', icon: Wallet },
];

function readPreference<T extends string>(key: string, fallback: T): T {
  try { return (localStorage.getItem(key) as T) || fallback; } catch { return fallback; }
}
function readMode(): Mode {
  return readPreference<string>('actuallyfree-mode', 'manual') === 'auto' ? 'auto' : 'manual';
}
function writePreference(key: string, value: string) {
  try { localStorage.setItem(key, value); } catch { /* Preferences remain available for this session. */ }
}
function usePreferences() {
  const preferences = useContext(PreferencesContext);
  if (!preferences) throw new Error('Preferences must be used within the app provider.');
  return preferences;
}
function Shell({ page, children }: { page: PageId; children: ReactNode }) {
  const { mode, compact } = usePreferences();
  return <div className={`app-shell ${compact ? 'compact' : ''}`}>
    <aside className="sidebar" aria-label="Main navigation">
      <Link href="/" className="flex items-center gap-3 px-2 mb-10" data-testid="link-brand-home">
        <span className="brand-mark"><Gamepad2 size={19} strokeWidth={2.5}/></span>
        <span><span className="block text-[17px] font-extrabold tracking-[-.05em] text-[#f1eff9]">actually<span className="text-[#a991ff]">free</span></span><span className="block text-[9px] tracking-[.17em] uppercase text-[#77778d]">know before you click.</span></span>
      </Link>
      <div className="eyebrow px-3 mb-3">Your space</div>
      <nav className="flex flex-col gap-1">
        {navItems.map(({ id, label, href, icon: Icon }) => <Link key={id} href={href} className={`nav-link ${page === id ? 'active' : ''}`} aria-current={page === id ? 'page' : undefined} data-testid={`link-nav-${id}`}><Icon size={17}/><span>{label}</span>{id === 'wallet' && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#7e7a90]"/>}</Link>)}
      </nav>
      <div className="mt-8 px-3 mb-3 eyebrow">Preferences</div>
      <Link href="/settings" className={`nav-link ${page === 'settings' ? 'active' : ''}`} aria-current={page === 'settings' ? 'page' : undefined} data-testid="link-nav-settings"><Settings size={17}/><span>Settings</span></Link>
      <div className="mt-auto panel p-4">
        <div className="flex items-center gap-2 text-[#d8d2e8] text-xs font-bold"><ShieldCheck size={15} className="text-[#8be0d0]"/> Player-first promise</div>
        <p className="text-[10px] text-[#85859a] leading-relaxed mt-2">No ads. No password requests. No pretend rewards.</p>
        <div className="flex items-center gap-1.5 mt-3 text-[9px] tracking-wide text-[#77778d]"><LockKeyhole size={11}/> PRIVATE BY DESIGN</div>
      </div>
      <div className="flex items-center gap-3 pt-5 px-2">
        <div className="w-8 h-8 rounded-full border border-[#343343] bg-[#22212f] grid place-items-center text-[11px] font-extrabold text-[#c8baff]">AF</div>
        <div><div className="text-[11px] font-bold text-[#dddbe7]">Guest player</div><div className="text-[9px] text-[#77778d]">Local preview</div></div>
        <button className="ml-auto text-[#77778d] hover:text-[#e6e1f1]" aria-label="About ActuallyFree" data-testid="button-about" onClick={() => window.alert('ActuallyFree is a discovery preview. No provider offers or rewards are connected yet.')}><CircleHelp size={16}/></button>
      </div>
    </aside>
    <div className="main-area">
      <header className="topbar">
        <div className="flex items-center gap-2 text-xs text-[#88889c]"><span className="hidden sm:inline">Your player hub</span><ChevronRight size={13} className="hidden sm:block"/><span className="text-[#e5e2ee] font-bold">{navItems.find(n => n.id === page)?.label || 'Settings'}</span></div>
        <div className="flex items-center gap-3">
          <span className="device-chip"><Monitor size={12}/> WINDOWS <span className="text-[#59596c]">/</span><Smartphone size={12}/> ANDROID</span>
          <button disabled className="w-9 h-9 rounded-xl border border-[#2b2b3a] bg-[#1b1b26] grid place-items-center text-[#777688] cursor-not-allowed" aria-label="Notifications unavailable" title="Notifications are not connected" data-testid="button-notifications"><Bell size={15}/></button>
        </div>
      </header>
      <main className="content-wrap fade-up">{children}</main>
    </div>
    <nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map(({ id, label, href, icon: Icon }) => <Link key={id} href={href} className={page === id ? 'active' : ''} aria-current={page === id ? 'page' : undefined} data-testid={`mobile-nav-${id}`}><Icon size={17}/><span>{label}</span></Link>)}<Link href="/settings" className={page === 'settings' ? 'active' : ''} aria-current={page === 'settings' ? 'page' : undefined} data-testid="mobile-nav-settings"><Settings size={17}/><span>Settings</span></Link></nav>
    <div className="sr-only" aria-live="polite">{mode === 'auto' ? 'AI preview mode selected; automation unavailable' : 'Manual discovery mode selected'}</div>
  </div>;
}

function ModePicker() {
  const { mode, setMode } = usePreferences();
  return <div>
    <div className="eyebrow mb-2.5">Discovery mode</div>
    <div className="mode-control" role="group" aria-label="Discovery mode">
      <button className={`mode-button ${mode === 'manual' ? 'selected' : ''}`} onClick={() => setMode('manual')} aria-pressed={mode === 'manual'} data-testid="button-mode-manual"><Gamepad2 size={14}/> Manual</button>
      <button className={`mode-button ${mode === 'auto' ? 'selected' : ''}`} onClick={() => setMode('auto')} aria-pressed={mode === 'auto'} data-testid="button-mode-ai"><Sparkles size={14}/> AI preview</button>
    </div>
    <p className="mt-2 text-[10px] text-[#77778c]">{mode === 'auto' ? 'AI mode is a visual preview only. No gameplay, missions, or surveys are automated.' : 'Browse and decide for yourself. No actions happen in the background.'}</p>
  </div>;
}

function LiveUnavailable({ label = 'Not connected yet' }: { label?: string }) {
  return <div className="notice flex items-start gap-3 p-4">
    <span className="mt-0.5 text-[#aa91ff]"><WifiOff size={16}/></span><div><div className="text-xs font-extrabold text-[#ddd4f5]">{label}</div><p className="text-[11px] text-[#918ba4] leading-relaxed mt-1">Live data isn’t connected. This preview does not show earnings, claimable offers, or completed activity.</p></div>
  </div>;
}

function BackendSetupStatus() {
  const { data, isLoading, isError } = useGetSystemStatus();
  const databaseLabel = isLoading
    ? 'Checking'
    : isError || !data
      ? 'Status unavailable'
      : data.databaseState === 'connected'
        ? 'Connected'
        : data.databaseState === 'not_configured'
          ? 'Not configured'
          : 'Unavailable';
  const providerLabel = isLoading
    ? 'Checking'
    : isError || !data
      ? 'Status unavailable'
      : data.rewardProviderState === 'credentials_configured'
        ? 'Signing credentials configured'
        : 'Not configured';
  const authLabel = isLoading
    ? 'Checking'
    : isError || !data
      ? 'Status unavailable'
      : data.accountAuthState === 'configured'
        ? 'Configured'
        : 'Not configured';

  return <section className="panel mt-4 p-5" aria-label="Backend setup status" data-testid="backend-setup-status">
    <div className="flex items-start justify-between gap-4">
      <div>
        <div className="eyebrow mb-1">BACKEND SETUP</div>
        <h2 className="font-['Space_Grotesk'] text-base font-bold">Setup status</h2>
      </div>
      <span className="rounded-full border border-[#51422e] bg-[#382e20]/50 px-2.5 py-1 text-[9px] font-bold uppercase tracking-wide text-[#e6bd7d]">
        {isLoading
          ? 'Checking'
          : isError || !data
            ? 'Status unavailable'
            : data.overallState === 'ready'
              ? 'Ready'
              : 'Setup required'}
      </span>
    </div>
    <div className="mt-4 grid gap-2 sm:grid-cols-3">
      {[
        ['Database', databaseLabel],
        ['Reward provider', providerLabel],
        ['Account login', authLabel],
      ].map(([label, value]) => <div key={label} className="rounded-lg border border-white/[.06] bg-black/10 px-3 py-2.5">
        <div className="text-[9px] uppercase tracking-wide text-[#858398]">{label}</div>
        <div className="mt-1 text-[10px] font-bold text-[#d8d4e4]">{value}</div>
      </div>)}
    </div>
    <p className="mt-3 text-[10px] leading-relaxed text-[#8e8c9f]">
      {isError || !data
        ? 'Backend status could not be confirmed. No live offers, balances, or rewards are assumed.'
        : data.realRewardsEnabled
          ? 'Reward processing is enabled only for verified provider events.'
          : 'Real reward credits are disabled until account login and provider verification are configured. Demo points are never spendable.'}
    </p>
  </section>;
}

function HomePage() {
  return <Shell page="home"><div className="flex flex-wrap items-end justify-between gap-5 mb-7">
    <div><div className="eyebrow mb-3">PLAYER HUB / 01</div><h1 className="page-title">A clearer way to<br className="sm:hidden"/> find rewards.</h1><p className="text-sm text-[#9695a8] mt-3 max-w-lg">Explore legitimate ways to earn, with the details upfront and your account kept yours.</p></div><ModePicker/>
  </div>
  <div className="panel grid-line relative overflow-hidden p-6 sm:p-8 mb-5">
    <div className="absolute -right-12 -top-20 w-72 h-72 rounded-full border border-[#826bd2]/10"/><div className="absolute right-3 top-[-100px] w-64 h-64 rounded-full border border-[#826bd2]/10"/>
    <div className="relative grid md:grid-cols-[1.3fr_.7fr] gap-8 items-center">
      <div><div className="flex items-center gap-2 mb-4"><span className="w-2 h-2 rounded-full bg-[#f1bb6b]"/><span className="eyebrow text-[#c8ad7f]">EARLY ACCESS PREVIEW</span></div>
      <h2 className="font-['Space_Grotesk'] text-2xl sm:text-[30px] tracking-[-.04em] font-bold max-w-lg">No noise. No guesswork.<br/><span className="text-[#a992ff]">Just the next good thing.</span></h2>
      <p className="text-xs leading-relaxed text-[#9694a7] mt-4 max-w-md">ActuallyFree is being built around transparent reward discovery for Roblox players. Right now, provider listings and account data are not connected.</p>
      <div className="flex flex-wrap gap-2 mt-5"><Link href="/missions" className="inline-flex items-center gap-2 rounded-lg bg-[#a28aff] px-4 py-2.5 text-[11px] font-extrabold text-[#17131f] hover:bg-[#b5a4ff] transition-colors" data-testid="link-explore-missions">Explore missions <ArrowRight size={14}/></Link><Link href="/surveys" className="inline-flex items-center gap-2 rounded-lg border border-[#353444] px-4 py-2.5 text-[11px] font-bold text-[#d1cedd] hover:bg-white/[.04] transition-colors" data-testid="link-explore-surveys">Browse surveys</Link></div>
      </div>
      <div className="hidden md:flex justify-center"><div className="relative w-[210px] h-[210px] rounded-full border border-[#7663bd]/20 grid place-items-center"><div className="absolute inset-5 rounded-full border border-[#7663bd]/20"/><div className="absolute inset-11 rounded-full border border-dashed border-[#8271c4]/30"/><div className="w-[88px] h-[88px] rounded-[27px] bg-gradient-to-br from-[#8069dc] to-[#43599f] rotate-[-8deg] grid place-items-center shadow-[0_18px_55px_rgba(111,91,207,.2)]"><Gamepad2 size={38} className="text-[#eeeaff]" strokeWidth={1.5}/></div><span className="absolute top-8 right-8 w-2 h-2 rounded-full bg-[#72d8cb]"/><span className="absolute bottom-7 left-10 w-1.5 h-1.5 rounded-full bg-[#b58fff]"/></div></div>
    </div>
  </div>
  <div className="grid md:grid-cols-2 gap-4 mb-5">
    <div className="panel p-5 sm:p-6"><div className="flex items-center justify-between"><div className="eyebrow">POINTS BALANCE</div><Wallet size={17} className="text-[#a78bfa]"/></div><div className="mt-5 flex items-baseline gap-2"><span className="font-['Space_Grotesk'] text-4xl font-bold tracking-tight text-[#ece9f4]">—</span><span className="text-xs text-[#87869a]">points</span></div><div className="mt-4 pt-4 border-t border-white/[.06] flex items-center gap-2 text-[10px] text-[#85849a]"><Info size={13} className="text-[#a78bfa]"/> Balance unavailable until live data connects</div></div>
    <div className="panel p-5 sm:p-6"><div className="flex items-center justify-between"><div className="eyebrow">MISSION PROGRESS</div><Activity size={17} className="text-[#68c9d5]"/></div><div className="mt-5 flex items-baseline gap-2"><span className="font-['Space_Grotesk'] text-4xl font-bold tracking-tight text-[#ece9f4]">—</span><span className="text-xs text-[#87869a]">of — complete</span></div><div className="mt-4 pt-4 border-t border-white/[.06] flex items-center gap-2 text-[10px] text-[#85849a]"><Info size={13} className="text-[#68c9d5]"/> Progress is not connected</div></div>
  </div>
  <div className="grid lg:grid-cols-[1.15fr_.85fr] gap-4">
    <section className="panel p-5 sm:p-6"><div className="flex items-center justify-between mb-5"><div><div className="eyebrow mb-1">DISCOVER</div><h3 className="font-['Space_Grotesk'] text-lg font-bold">Find your next path</h3></div><Compass size={18} className="text-[#9890ba]"/></div>
      <div className="grid sm:grid-cols-2 gap-3">
        <Link href="/missions" className="group rounded-xl border border-[#30303f] bg-[#1b1b27] p-4 hover:border-[#7661c1]/60 transition-colors" data-testid="card-discover-missions"><div className="flex items-center justify-between"><span className="w-9 h-9 rounded-xl bg-[#7157c8]/15 grid place-items-center text-[#b39cff]"><Target size={17}/></span><ArrowRight size={14} className="text-[#747388] group-hover:text-[#c0adff]"/></div><div className="mt-4 text-xs font-extrabold">Missions</div><div className="text-[10px] text-[#85849a] mt-1">Tasks and partner activities</div><div className="mt-3 text-[9px] uppercase tracking-[.12em] text-[#b29cff]">Catalog unavailable</div></Link>
        <Link href="/surveys" className="group rounded-xl border border-[#30303f] bg-[#1b1b27] p-4 hover:border-[#4d8c9a]/60 transition-colors" data-testid="card-discover-surveys"><div className="flex items-center justify-between"><span className="w-9 h-9 rounded-xl bg-[#40aabd]/10 grid place-items-center text-[#6ecbd5]"><BarChart3 size={17}/></span><ArrowRight size={14} className="text-[#747388] group-hover:text-[#6ecbd5]"/></div><div className="mt-4 text-xs font-extrabold">Surveys</div><div className="text-[10px] text-[#85849a] mt-1">Share opinions, on your terms</div><div className="mt-3 text-[9px] uppercase tracking-[.12em] text-[#6ecbd5]">Catalog unavailable</div></Link>
      </div>
    </section>
    <section className="panel p-5 sm:p-6"><div className="eyebrow mb-1">THE ACTUALLYFREE STANDARD</div><h3 className="font-['Space_Grotesk'] text-lg font-bold mb-4">Trust should be the default.</h3>
      <div className="space-y-4">{[{icon:ShieldCheck,title:'No ads, ever',detail:'Discovery without ad placements.'},{icon:LockKeyhole,title:'Never share your password',detail:'We will never ask for Roblox credentials.'},{icon:BadgeCheck,title:'Clear before you click',detail:'Offers must be verified before they appear.'}].map(({icon:Icon,title,detail})=><div key={title} className="flex items-start gap-3"><span className="w-8 h-8 rounded-lg bg-[#252432] grid place-items-center text-[#91d5cb] shrink-0"><Icon size={15}/></span><div><div className="text-[11px] font-extrabold">{title}</div><div className="text-[10px] mt-1 text-[#89889b]">{detail}</div></div><Check size={13} className="ml-auto text-[#709c93] mt-1"/></div>)}</div>
    </section>
  </div>
  <div className="mt-5"><LiveUnavailable label="Live rewards are not connected"/></div>
  <BackendSetupStatus/>
  </Shell>;
}

function CatalogPage({ page }: { page: 'missions' | 'surveys' }) {
  return <Shell page={page}><OfferExplorer page={page}/></Shell>;
}

function LeaderboardPage() {
  return <Shell page="leaderboard"><div className="mb-7"><div className="eyebrow mb-3">COMMUNITY / 04</div><h1 className="page-title">Leaderboard</h1><p className="text-sm text-[#9695a8] mt-3">A fair view of community progress, when there’s real data to show.</p></div>
    <div className="panel grid-line min-h-[370px] grid place-items-center p-8"><div className="text-center max-w-sm"><div className="empty-orbit mx-auto mb-5"><Trophy size={27} strokeWidth={1.5}/></div><div className="eyebrow mb-2">RANKINGS UNAVAILABLE</div><h2 className="font-['Space_Grotesk'] text-xl font-bold">No live leaderboard yet</h2><p className="text-xs text-[#8c8b9e] leading-relaxed mt-3">Rankings will only appear once verified activity data is connected. We won’t fill this space with made-up players or scores.</p><div className="mt-5 inline-flex items-center gap-2 rounded-full border border-[#343342] px-3 py-1.5 text-[9px] uppercase tracking-[.12em] text-[#a4a1b4]"><WifiOff size={12}/> Live data not connected</div></div></div>
    <p className="mt-5 text-[10px] text-[#737286] flex gap-2 items-center"><ShieldCheck size={13} className="text-[#7cc9b6]"/> No fabricated rankings or player identities are shown.</p>
  </Shell>;
}

function WalletPage() {
  return <Shell page="wallet"><div className="mb-7"><div className="eyebrow mb-3">REWARDS / 05</div><h1 className="page-title">Your wallet</h1><p className="text-sm text-[#9695a8] mt-3">A transparent view of points, history, and redemption options.</p></div>
    <div className="grid md:grid-cols-[1fr_.78fr] gap-4 mb-4">
      <div className="panel p-6 sm:p-7"><div className="eyebrow">AVAILABLE POINTS</div><div className="flex items-baseline gap-2 mt-4"><span className="font-['Space_Grotesk'] font-bold text-[48px] tracking-[-.05em]">—</span><span className="text-sm text-[#8a899d]">pts</span></div><div className="mt-4 flex gap-2 items-center text-[10px] text-[#8a899d]"><span className="w-1.5 h-1.5 rounded-full bg-[#e4b56c]"/> Balance unavailable</div></div>
      <div className="panel p-6"><div className="flex items-center gap-2 text-xs font-extrabold"><Gift size={16} className="text-[#b49aff]"/> Redemption options</div><p className="text-[11px] leading-relaxed text-[#88879a] mt-3">No rewards or Robux payouts are connected or claimable in this preview.</p><button disabled className="mt-5 w-full rounded-lg border border-[#333343] bg-[#20202b] px-3 py-2.5 text-[10px] font-bold text-[#777688] cursor-not-allowed" data-testid="button-redeem-disabled">Unavailable until rewards connect</button></div>
    </div>
    <LiveUnavailable label="Wallet data is not connected"/>
    <div className="panel mt-4 p-5"><div className="flex items-center justify-between"><div><div className="eyebrow mb-1">ACTIVITY</div><h2 className="text-sm font-extrabold">Recent history</h2></div><Clock3 size={16} className="text-[#8a899e]"/></div><div className="py-9 text-center"><div className="text-xs text-[#aaa8b8] font-bold">No activity to show</div><p className="text-[10px] mt-1 text-[#777688]">History will appear here only when live data is available.</p></div></div>
  </Shell>;
}

function SettingsPage() {
  const { notifications, setNotifications, compact, setCompact } = usePreferences();
  const [saved, setSaved] = useState(false);
  function toggle(value: boolean, setter: (value: boolean) => void) {
    setter(value);
    setSaved(true);
  }
  return <Shell page="settings"><div className="mb-7"><div className="eyebrow mb-3">YOUR SPACE / 06</div><h1 className="page-title">Settings</h1><p className="text-sm text-[#9695a8] mt-3">Small preferences, saved on this device.</p></div>
    <div className="grid lg:grid-cols-[1fr_300px] gap-4 items-start">
      <section className="panel p-5 sm:p-7"><div className="flex items-center justify-between mb-1"><div><div className="eyebrow mb-1">PREFERENCES</div><h2 className="font-['Space_Grotesk'] text-lg font-bold">Make it yours</h2></div>{saved && <span className="inline-flex items-center gap-1 text-[10px] text-[#85c6b7]"><Check size={12}/> Saved locally</span>}</div>
        <div className="setting-row"><div className="flex items-start gap-3"><span className="mt-0.5 text-[#a992ff]"><Bell size={16}/></span><div><div className="text-xs font-extrabold">Notifications</div><div className="text-[10px] text-[#858499] mt-1">Local preference only. No notifications are sent.</div></div></div><button className="switch" data-on={notifications} role="switch" aria-checked={notifications} aria-label="Toggle notifications preference" onClick={() => toggle(!notifications, setNotifications)} data-testid="switch-notifications"><span className="switch-dot block"/></button></div>
        <div className="setting-row"><div className="flex items-start gap-3"><span className="mt-0.5 text-[#78c8d3]"><Menu size={16}/></span><div><div className="text-xs font-extrabold">Compact layout</div><div className="text-[10px] text-[#858499] mt-1">Choose a denser discovery layout on this device.</div></div></div><button className="switch" data-on={compact} role="switch" aria-checked={compact} aria-label="Toggle compact layout preference" onClick={() => toggle(!compact, setCompact)} data-testid="switch-compact"><span className="switch-dot block"/></button></div>
        <div className="setting-row border-0"><div className="flex items-start gap-3"><span className="mt-0.5 text-[#d4a7eb]"><Moon size={16}/></span><div><div className="text-xs font-extrabold">Appearance</div><div className="text-[10px] text-[#858499] mt-1">The dark player theme is currently active.</div></div></div><span className="rounded-full border border-[#343343] px-2.5 py-1 text-[9px] text-[#a9a7b8]">DARK</span></div>
      </section>
       <aside className="space-y-4"><div className="panel p-5"><ModePicker/></div>
        <div className="panel p-5"><div className="flex items-center gap-2 text-xs font-extrabold"><LockKeyhole size={15} className="text-[#8bd5c5]"/> Account safety</div><ul className="mt-4 space-y-3 text-[10px] text-[#908fa1]"><li className="flex gap-2"><Check size={12} className="text-[#78c7b7] shrink-0"/> Never enter your Roblox password here.</li><li className="flex gap-2"><Check size={12} className="text-[#78c7b7] shrink-0"/> Preferences stay in this browser.</li><li className="flex gap-2"><Check size={12} className="text-[#78c7b7] shrink-0"/> No providers or account data connected.</li></ul></div>
        <div className="panel p-5"><div className="eyebrow mb-2">PLATFORM SUPPORT</div><div className="flex gap-2"><span className="device-chip"><Monitor size={12}/> Windows</span><span className="device-chip"><Smartphone size={12}/> Android</span></div></div>
      </aside>
     </div>
     <div className="mt-4"><BackendSetupStatus/></div>
  </Shell>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomePage}/>
    <Route path="/missions"><CatalogPage page="missions"/></Route>
    <Route path="/surveys"><CatalogPage page="surveys"/></Route>
    <Route path="/leaderboard" component={LeaderboardPage}/>
    <Route path="/wallet" component={WalletPage}/>
    <Route path="/settings" component={SettingsPage}/>
    <Route component={NotFound}/>
  </Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  const [mode, setModeState] = useState<Mode>(readMode);
  const [compact, setCompactState] = useState(() => readPreference<'on' | 'off'>('actuallyfree-compact', 'off') === 'on');
  const [notifications, setNotificationsState] = useState(() => readPreference<'on' | 'off'>('actuallyfree-notifications', 'off') === 'on');
  const setMode = (next: Mode) => { setModeState(next); writePreference('actuallyfree-mode', next); };
  const setCompact = (next: boolean) => { setCompactState(next); writePreference('actuallyfree-compact', next ? 'on' : 'off'); };
  const setNotifications = (next: boolean) => { setNotificationsState(next); writePreference('actuallyfree-notifications', next ? 'on' : 'off'); };
  const preferences = { mode, setMode, compact, setCompact, notifications, setNotifications };
  return <PreferencesContext.Provider value={preferences}><QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider></PreferencesContext.Provider>;
}
export default App;
