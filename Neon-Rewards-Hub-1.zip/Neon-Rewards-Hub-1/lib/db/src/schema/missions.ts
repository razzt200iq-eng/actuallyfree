import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  check,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { offerKindEnum } from "./enums";

export const missionListingsTable = pgTable(
  "actuallyfree_mission_listings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    providerId: text("provider_id"),
    providerOfferId: text("provider_offer_id"),
    kind: offerKindEnum("kind").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull(),
    category: text("category"),
    durationMinutes: integer("duration_minutes").notNull(),
    rewardPoints: integer("reward_points").notNull(),
    requirements: jsonb("requirements").$type<string[]>().notNull().default([]),
    isDemo: boolean("is_demo").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    providerVerifiedAt: timestamp("provider_verified_at", {
      withTimezone: true,
    }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("actuallyfree_mission_provider_offer_unique").on(
      table.providerId,
      table.providerOfferId,
    ),
    check(
      "actuallyfree_mission_duration_positive",
      sql`${table.durationMinutes} > 0`,
    ),
    check(
      "actuallyfree_mission_reward_nonnegative",
      sql`${table.rewardPoints} >= 0`,
    ),
    check(
      "actuallyfree_live_mission_has_provider",
      sql`${table.isDemo} = true OR (${table.providerId} IS NOT NULL AND ${table.providerOfferId} IS NOT NULL AND ${table.providerVerifiedAt} IS NOT NULL)`,
    ),
  ],
);

export const insertMissionListingSchema = createInsertSchema(
  missionListingsTable,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMissionListing = z.infer<typeof insertMissionListingSchema>;
export type MissionListing = typeof missionListingsTable.$inferSelect;
