import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import {
  check,
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import {
  ledgerDirectionEnum,
  ledgerSourceEnum,
  missionStateEnum,
  rewardEventOutcomeEnum,
  rewardEventStatusEnum,
  withdrawalStatusEnum,
} from "./enums";
import { missionAttemptsTable } from "./mission-attempts";
import { usersTable } from "./users";

export const rewardEventsTable = pgTable(
  "actuallyfree_reward_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    providerId: text("provider_id").notNull(),
    providerEventId: text("provider_event_id").notNull(),
    attemptRef: text("attempt_ref").notNull(),
    attemptId: uuid("attempt_id").references(() => missionAttemptsTable.id, {
      onDelete: "set null",
    }),
    userId: uuid("user_id").references(() => usersTable.id, {
      onDelete: "set null",
    }),
    outcome: rewardEventOutcomeEnum("outcome").notNull(),
    status: rewardEventStatusEnum("status").notNull().default("received"),
    receivedAt: timestamp("received_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    processedAt: timestamp("processed_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("actuallyfree_reward_provider_event_unique").on(
      table.providerId,
      table.providerEventId,
    ),
    index("actuallyfree_reward_events_attempt_idx").on(table.attemptRef),
  ],
);

export const pointsLedgerTable = pgTable(
  "actuallyfree_points_ledger",
  {
    eventId: text("event_id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    direction: ledgerDirectionEnum("direction").notNull(),
    amountPoints: integer("amount_points").notNull(),
    source: ledgerSourceEnum("source").notNull(),
    sourceId: text("source_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("actuallyfree_points_ledger_user_created_idx").on(
      table.userId,
      table.createdAt,
    ),
    uniqueIndex("actuallyfree_points_ledger_source_unique").on(
      table.source,
      table.sourceId,
    ),
    check(
      "actuallyfree_points_ledger_amount_positive",
      sql`${table.amountPoints} > 0`,
    ),
  ],
);

export const withdrawalRequestsTable = pgTable(
  "actuallyfree_withdrawal_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "restrict" }),
    idempotencyKey: text("idempotency_key").notNull(),
    amountPoints: integer("amount_points").notNull(),
    status: withdrawalStatusEnum("status").notNull().default("requested"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("actuallyfree_withdrawal_user_idempotency_unique").on(
      table.userId,
      table.idempotencyKey,
    ),
    index("actuallyfree_withdrawals_user_created_idx").on(
      table.userId,
      table.createdAt,
    ),
    check(
      "actuallyfree_withdrawal_amount_positive",
      sql`${table.amountPoints} > 0`,
    ),
  ],
);

export const insertRewardEventSchema = createInsertSchema(
  rewardEventsTable,
).omit({
  id: true,
  receivedAt: true,
  processedAt: true,
});

export const insertPointsLedgerEntrySchema = createInsertSchema(
  pointsLedgerTable,
);

export const insertWithdrawalRequestSchema = createInsertSchema(
  withdrawalRequestsTable,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
});

export type InsertRewardEvent = z.infer<typeof insertRewardEventSchema>;
export type PointsLedgerEntry = typeof pointsLedgerTable.$inferSelect;
export type InsertWithdrawalRequest = z.infer<
  typeof insertWithdrawalRequestSchema
>;
export type WithdrawalRequest = typeof withdrawalRequestsTable.$inferSelect;
export type MissionAttemptState = typeof missionStateEnum.enumValues[number];
