import { pgEnum } from "drizzle-orm/pg-core";

export const offerKindEnum = pgEnum("actuallyfree_offer_kind", [
  "mission",
  "survey",
]);

export const missionStateEnum = pgEnum("actuallyfree_mission_state", [
  "available",
  "started",
  "pending_verification",
  "verified",
  "rejected",
]);

export const rewardEventOutcomeEnum = pgEnum(
  "actuallyfree_reward_event_outcome",
  ["verified", "rejected"],
);

export const rewardEventStatusEnum = pgEnum(
  "actuallyfree_reward_event_status",
  ["received", "applied", "rejected"],
);

export const ledgerDirectionEnum = pgEnum("actuallyfree_ledger_direction", [
  "credit",
  "debit",
]);

export const ledgerSourceEnum = pgEnum("actuallyfree_ledger_source", [
  "verified_provider_event",
  "withdrawal_request",
  "withdrawal_refund",
]);

export const withdrawalStatusEnum = pgEnum(
  "actuallyfree_withdrawal_status",
  ["requested", "approved", "rejected", "paid", "cancelled"],
);
