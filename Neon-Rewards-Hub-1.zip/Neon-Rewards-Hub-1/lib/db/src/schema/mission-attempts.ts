import { createInsertSchema } from "drizzle-zod";
import {
  index,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { missionStateEnum } from "./enums";
import { missionListingsTable } from "./missions";
import { usersTable } from "./users";

export const missionAttemptsTable = pgTable(
  "actuallyfree_mission_attempts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    missionId: uuid("mission_id")
      .notNull()
      .references(() => missionListingsTable.id, { onDelete: "restrict" }),
    providerAttemptRef: text("provider_attempt_ref").notNull().unique(),
    state: missionStateEnum("state").notNull().default("available"),
    startedAt: timestamp("started_at", { withTimezone: true }),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    verifiedAt: timestamp("verified_at", { withTimezone: true }),
    rejectedAt: timestamp("rejected_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("actuallyfree_attempts_user_state_idx").on(table.userId, table.state),
    index("actuallyfree_attempts_mission_idx").on(table.missionId),
  ],
);

export const insertMissionAttemptSchema = createInsertSchema(
  missionAttemptsTable,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMissionAttempt = z.infer<typeof insertMissionAttemptSchema>;
export type MissionAttempt = typeof missionAttemptsTable.$inferSelect;
